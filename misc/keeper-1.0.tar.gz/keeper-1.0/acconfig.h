/* Have pthread mutex locking and unlocking functions in libc */
#undef HAVE_PTHREAD_MUTEX
