/*
 * test_reload.c: An example for the keeper configuration library
 *
 * Copyright (C) 1999-2000 Miklos Szeredi
 * Email: mszeredi@inf.bme.hu
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA
 */

#include <keeper.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define TESTDIR "u/kptest/reload:"

int main(void)
{
    char *s;
    char *lasts = NULL;

    while(1) {
        s = NULL;
        kp_get_string(TESTDIR "/string", &s);
        if((s && lasts && strcmp(s, lasts) != 0) || 
           ((!s || !lasts) && s != lasts))
            printf("value: '%s'\n", s ? s : "(null)");
        free(lasts);
        lasts = s;
        sleep(1);
    }
}
