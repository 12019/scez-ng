/*
 * example: An example for the keeper configuration library
 *
 * Copyright (C) 1999-2000 Miklos Szeredi
 * Email: mszeredi@inf.bme.hu
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA
 */

#include <keeper.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    RED,
    WHITE,
    GREEN
};

static const char *enumname[] = { "RED", "WHITE", "GREEN", NULL };

int main(int argc, char *argv[])
{
    KPDIR *d;

    if(argc != 2) {
        fprintf(stderr, "Usage: %s <set|get|del>\n", argv[0]);
        exit(1);
    }
    
    /* Using KPDIR is a shorthand, nothing more:

          d = kp_dir_open("u/kptest/example:");
          kp_set_string(KP_P(d, "stringtest"), "123");
          kp_dir_close(d);

       is equivalent to

          kp_set_string("u/kptest/example:/stringtest", "123");
    */


    d = kp_dir_open("u/kptest/example:");

    if(strcmp(argv[1], "set") == 0) {
        /* When setting values, we don't care about possible errors.
           If you know what you are doing, kp_set_XXX() will not
           fail.

           Remember, that after setting the values, call kp_flush() to
           commit the new data to disk.  */
        
        kp_set_data   (KP_P(d, "datatest"),   "123456789", 6);
        kp_set_string (KP_P(d, "stringtest"), "123");
        kp_set_int    (KP_P(d, "inttest"),    123);
        kp_set_float  (KP_P(d, "floattest"),  123.456789);
        kp_set_bool   (KP_P(d, "booltest"),   1);
        kp_set_enum   (KP_P(d, "enumtest"),   enumname, GREEN);
        
        kp_flush();
    }
    else if(strcmp(argv[1], "get") == 0) {
        /* When getting values, it can usually fail if the key is not
           set.  You can deal with this in two different ways:

             1) check the return value of kp_get_XXX()
             2) set a default value before calling kp_get_XXX()

	   Here the 2) approach is used.

           Remember that in case of DATA and STRING types, if
           kp_get_value() succeeded, you must free() the returned
           value.
        */

        unsigned int datalen = 0;
        void *rawdata = NULL;
        char *strdata = NULL;
        int intdata = -1;
        double floatdata = 0.0;
        int booldata = -1;
        int enumdata = -1;
        
        kp_get_data   (KP_P(d, "datatest"),   &rawdata, &datalen);
        kp_get_string (KP_P(d, "stringtest"), &strdata);
        kp_get_int    (KP_P(d, "inttest"),    &intdata);
        kp_get_float  (KP_P(d, "floattest"),  &floatdata);
        kp_get_bool   (KP_P(d, "booltest"),   &booldata);
        kp_get_enum   (KP_P(d, "enumtest"),   enumname, &enumdata);

        printf("datatest: '%.*s'\n", (int) datalen, 
               rawdata  == NULL ? "" : (char *) rawdata);
        printf("stringtest: '%s'\n", strdata == NULL ? "(none)" : strdata);
        printf("inttest: %i\n", intdata);
        printf("floattest: %g\n", floatdata);
        printf("booltest: %s\n", booldata < 0 ? "(none)" :
               (booldata ? "TRUE" : "FALSE"));
        printf("enumtest: %s\n", enumdata < 0 ? "(none)" : enumname[enumdata]);

        free(rawdata);
        free(strdata);
    }
    else if(strcmp(argv[1], "del") == 0) {
        /* When removing keys, we don't care about failure.

           Remember, that after removing values, call kp_flush() to
           commit it to disk. 
        */

        kp_remove(KP_P(d, "datatest"));
        kp_remove(KP_P(d, "stringtest"));
        kp_remove(KP_P(d, "inttest"));
        kp_remove(KP_P(d, "floattest"));
        kp_remove(KP_P(d, "booltest"));
        kp_remove(KP_P(d, "enumtest"));

        kp_flush();
    }

    kp_dir_close(d);
    
    return 0;
}
