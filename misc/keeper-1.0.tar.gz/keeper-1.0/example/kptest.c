/*
 * kptest: Test program for the keeper library
 *
 * Copyright (C) 1999-2000 Miklos Szeredi
 * Email: mszeredi@inf.bme.hu
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA
 */

#include <keeper.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/wait.h>
#include <unistd.h>

#define TESTDIR "u/kptest/test:"

static char *str1 = "1";
static char *str2 = "2";

#if 0
static void smsleep()
{
    struct timespec ts;

    ts.tv_sec = 0;
    ts.tv_nsec = 1000 * 1000 * 100;

    nanosleep(&ts, NULL);
}
#endif

static void *test_func1(void *param)
{
    char testkey[256];
    int i;
    int testnum = 100;
    int res;

    for(i = 0; i < testnum; i++) {
        sprintf(testkey, "%s/test%02i", TESTDIR, i);
        res = kp_set_string(testkey, str1);
        printf("1 -- %s: %s\n", testkey, kp_strerror(res));
/*        smsleep(); */
        kp_flush();
    }
    return NULL;
}


static void *test_func2(void *param)
{
    char testkey[256];
    int i;
    int testnum = 100;
    int res;

    for(i = testnum - 1; i >= 0; i--) {
        sprintf(testkey, "%s/test%02i", TESTDIR, i);
        res = kp_set_string(testkey, str2);
        printf("2 -- %s: %s\n", testkey, kp_strerror(res));
/*        smsleep(); */
        kp_flush();
    }

    return NULL;
}

void thread_try()
{
    int res;
    pthread_t thrid1, thrid2;
    void *status;

    res = pthread_create(&thrid1, NULL, test_func1, NULL);
    if(res != 0) {
        perror("pthread_create");
        exit(1);
    }

    res = pthread_create(&thrid2, NULL, test_func2, NULL);
    if(res != 0) {
        perror("pthread_create");
        exit(1);
    }

    pthread_join(thrid1, &status);
    pthread_join(thrid2, &status);
}

void fork_try()
{
    int pid1, pid2;
    int status;

    pid1 = fork();
    if(pid1 == 0) {
        test_func1(NULL);
        exit(0);
    }

    pid2 = fork();
    if(pid2 == 0) {
        test_func2(NULL);
        exit(0);
    }

    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);
}

int main(int argc, char *argv[])
{
    if(argc >= 3) {
        str1 = argv[1];
        str2 = argv[2];
    }
    
/*     fork_try(); */

     thread_try();

    return 0;
}

